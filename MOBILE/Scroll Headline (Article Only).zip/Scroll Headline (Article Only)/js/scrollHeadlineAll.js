window.addEventListener("load", function () {
    var headline = document.querySelector('#scrollheadline');
    var headline__big = document.querySelector('.headline__big');
    var headline_tekno = document.querySelector('.headline-tekno');
    var imgHL = document.querySelector('#scrollheadline');
    var imageSrcWp = 'images/260x200.jpg';
    var imageSrc = 'images/750x500.jpg';
    var linkSrc = '#';


    //get img 780x390


    //create element
    //--
    var scrollHeadline = document.createElement("div");
    scrollHeadline.setAttribute("class", "scrollHeadline");
    //--
    var divtekno = document.createElement("div");
    divtekno.setAttribute("class", "scrollHeadline");
    //--
    var imgBannerWp = document.createElement("img");
    imgBannerWp.setAttribute("src", imageSrcWp);
    var imgBanner = document.createElement("img");
    imgBanner.setAttribute("src", imageSrc);
    //--
    var linkBanner = document.createElement("a");
    linkBanner.setAttribute("href", linkSrc);
    linkBanner.setAttribute("target", "_blank");
    //--
    var closeBanner = document.createElement("span");
    var textcloseBanner = document.createTextNode("X");
    closeBanner.setAttribute("class", "closebanner");
    //--
    var trigger = document.createElement("span");
    var textTrigger = document.createTextNode("CLICK TO EXPAND");
    trigger.setAttribute("class", "trigger");

    function postElement() {
        scrollHeadline.appendChild(linkBanner);
        scrollHeadline.appendChild(closeBanner);
        closeBanner.appendChild(textcloseBanner);
    }

    
    // condition 
    function setDomain() {
        var sitename = document.location.href;
        switch (sitename) {          
            case "https://news.kompas.com/":
                console.log("kanal");
                forWpKanal();
                break;
            default:
                console.log("selain wp");
                var photo_390 = document.querySelector("#scrollheadline img");
                var photo_390_height = photo_390.naturalHeight;

                function cekHeight() {
                    if (photo_390_height == 390) {
                        trigger.style.width = "52%";
                        console.log("52");
                    } else {
                        trigger.style.width = "56%";
                        console.log("69");
                    }
                }
                cekHeight();
                forArticle();
                break;
        }
    }



    setDomain();

    function forWpKanal() {
        headline.appendChild(scrollHeadline);
        scrollHeadline.appendChild(imgBannerWp);
        postElement();
        scrollHeadline.classList.add("scrollHeadline_wp");
        headline.appendChild(trigger);
        trigger.appendChild(textTrigger);
        headline.classList.add("onAds");

        function closeAd() {
            headline.classList.add("offAds");
            scrollHeadline.classList.add("offAds");
            trigger.classList.add("offAds");
        }

        var closebanner = document.querySelector('.closebanner');

        closebanner.addEventListener("click", function () {
            closeAd();
        });

        trigger.addEventListener("click", function () {
            headline.classList.remove("offAds");
            scrollHeadline.classList.remove("offAds");
            trigger.classList.remove("offAds");
        });

        function autocloseAds() {
            setTimeout(function () {
                trigger.style.display = "block";
            }, 2000);
            setTimeout(function () {
                closeAd();
            }, 10000);
        }
        autocloseAds();

    }

    function forTeknoKanal() {
        headline_tekno.appendChild(scrollHeadline);
        scrollHeadline.appendChild(imgBannerWp);
        postElement();
        scrollHeadline.classList.add("scrollHeadline_wp");
        headline__big.appendChild(trigger);
        trigger.appendChild(textTrigger);
        headline__big.classList.add("onAds");

        function closeAd() {
            headline__big.classList.add("offAds");
            scrollHeadline.classList.add("offAds");
            trigger.classList.add("offAds");
        }

        var closebanner = document.querySelector('.closebanner');

        closebanner.addEventListener("click", function () {
            closeAd();
        });

        trigger.addEventListener("click", function () {
            headline__big.classList.remove("offAds");
            scrollHeadline.classList.remove("offAds");
            trigger.classList.remove("offAds");
        });

        function autocloseAds() {
            setTimeout(function () {
                trigger.style.display = "block";
            }, 2000);
            setTimeout(function () {
                closeAd();
            }, 10000);
        }
        autocloseAds();
    }

    function forArticle() {
        //append element        
        imgHL.appendChild(scrollHeadline);
        scrollHeadline.appendChild(imgBanner);
        postElement();
        imgHL.appendChild(trigger);
        trigger.appendChild(textTrigger);
        headline.classList.add("onAds");

        function closeAd() {
            headline.classList.add("offAds");
            scrollHeadline.classList.add("offAds");
            trigger.classList.add("offAds");
        }

        var closebanner = document.querySelector('.closebanner');

        closebanner.addEventListener("click", function () {
            closeAd();
        });

        trigger.addEventListener("click", function () {
            headline.classList.remove("offAds");
            scrollHeadline.classList.remove("offAds");
            trigger.classList.remove("offAds");
        });

        function autocloseAds() {
            setTimeout(function () {
                trigger.style.display = "block";
            }, 2000);
            setTimeout(function () {
                closeAd();
            }, 10000);
        }
        autocloseAds();
    }



    


});