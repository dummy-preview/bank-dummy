(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._300x600LifestyleAnticipation19 = function() {
	this.initialize(img._300x600LifestyleAnticipation19);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib._300x600LifestyleAnticipation2 = function() {
	this.initialize(img._300x600LifestyleAnticipation2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,277,203);


(lib._300x600LifestyleAnticipation20 = function() {
	this.initialize(img._300x600LifestyleAnticipation20);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib._300x600LifestyleAnticipation21 = function() {
	this.initialize(img._300x600LifestyleAnticipation21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.Awan = function() {
	this.initialize(img.Awan);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,316);


(lib.BG = function() {
	this.initialize(img.BG);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,960);


(lib.Button = function() {
	this.initialize(img.Button);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,275,54);


(lib.flavor = function() {
	this.initialize(img.flavor);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,213,67);


(lib.GHW = function() {
	this.initialize(img.GHW);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,91);


(lib.kursor = function() {
	this.initialize(img.kursor);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,21,22);


(lib.Logo300x600 = function() {
	this.initialize(img.Logo300x600);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,290,212);


(lib.pursue = function() {
	this.initialize(img.pursue);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,186,71);


(lib.talent = function() {
	this.initialize(img.talent);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,365,376);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AA1CKIAAgxIAvAAIAAAxgAhjCKIAAkTICEAAIAAAvIhRAAIAAA+IBKAAIAAAuIhKAAIAABJIBVAAIAAAvg");
	this.shape.setTransform(0.45,-5.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.5,-18.9,20,27.599999999999998);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAUCKIg5jTIAFDTIgsAAIAAkTIA9AAIA2DFIgFjFIArAAIAAETg");
	this.shape.setTransform(0,-2.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.6,-16.7,15.3,27.5);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF183A").s().p("ABCCKIAAgxIAuAAIAAAxgAgOCKIAAh3IguAAIAAB3IgzAAIAAkTIAzAAIAABuIAuAAIAAhuIAyAAIAAETg");
	this.shape.setTransform(0.425,-5.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.8,-19.6,22.5,27.5);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF183A").s().p("AAYCKIgkhzIgMAAIAABzIgzAAIAAkTIBSAAQAgAAAPAPQAOAPAAAiIAAAlQAAApgjANIArB4gAgYgNIAUAAQAMAAAFgFQAFgFAAgMIAAgnQAAgWgVAAIgVAAg");
	this.shape.setTransform(0.575,-4.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7,-18.4,15.2,27.599999999999998);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AANB7IgTABQgnAAgUgRQgSgRAAgjIAAiMQAAgnASgSQATgSAnAAQAnAAASASQASARAAAoIAACMQAAAcgMASIAcAbIgiAhgAgbhvQgGAIAAAUIAACEQAAASAGAIQAGAHAOAAQANAAAFgHQAGgHAAgSIAAiHQAAgTgFgIQgGgHgNAAQgOAAgGAIg");
	this.shape.setTransform(0.825,-3.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.6,-19.2,16.9,32.2);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF022A").s().p("Ag3B9QgSgQAAgkIAAiMQAAgmASgTQARgSAmAAQAnAAARASQATASgBAnIAAAnIgyAAIAAgmQAAgTgGgIQgFgHgNgBQgLAAgHAJQgFAIAAATIAACEQAAATAFAHQAGAIAMgBQANAAAFgGQAGgIAAgRIAAgnIAyAAIAAArQABAlgTAQQgRAQgmAAQglAAgTgRg");
	this.shape.setTransform(0.15,-5.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.3,-19.8,14.899999999999999,28.5);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag3B6QgTgRAAgiIAAjSIAzAAIAADKQAAASAGAIQAFAHAMAAQAOAAAGgHQAFgIAAgSIAAjKIAyAAIAADTQAAAigTARQgTARglAAQgkAAgTgSg");
	this.shape.setTransform(-0.025,-5.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.5,-19.1,15,27.900000000000002);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag3B6QgTgRAAgiIAAjSIAzAAIAADKQAAASAGAIQAFAHAMAAQAOAAAGgHQAFgIAAgSIAAjKIAyAAIAADTQAAAigTARQgTARglAAQgkAAgTgSg");
	this.shape.setTransform(-0.025,-4.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.5,-18.5,15,28);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYCKIAAkTIAxAAIAAETg");
	this.shape.setTransform(0,-5.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-19.2,5.1,27.5);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF012A").s().p("AgZCKIAAkTIAzAAIAAETg");
	this.shape.setTransform(0.05,-16.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-30.6,5.1,27.6);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.kursor();
	this.instance.setTransform(0,0,0.9048,0.9045);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(0,0,19,19.9), null);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Button();
	this.instance.setTransform(0,0,0.7454,0.7453);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(0,0,205,40.3), null);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Logo300x600();
	this.instance.setTransform(0,0,0.6207,0.6208);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(0,0,180,131.6), null);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.flavor();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(0,0,213,67), null);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pursue();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(0,0,186,71), null);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.BG();
	this.instance.setTransform(0,0,0.7,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(0,0,448,672), null);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Awan();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(0,0,300,316), null);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.talent();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,365,376), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600LifestyleAnticipation2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,277,203), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Logo300x600();
	this.instance.setTransform(0,0,0.9517,0.9517);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,276,201.8), null);


(lib.button1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgTfAu4MAAAhdvMAm/AAAMAAABdvg");
	this.shape.setTransform(125.975,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,250.8,600);


// stage content:
(lib.Kite300x600_HTML5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	// timeline functions:
	this.frame_0 = function() {
		///////////////////* this.button1.addEventListener("click", fl_ClickToGoToWebPage);
		//////////////////
		//////////////////function fl_ClickToGoToWebPage() {
		//////////////////	window.open(clickTAG, "_blank");
		//////////////////}*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(179));

	// maskbutton
	this.button1 = new lib.button1();
	this.button1.name = "button1";
	this.button1.setTransform(-5.75,115192.95,1.2023,1,0,0,0,-3.5,115200);
	new cjs.ButtonHelper(this.button1, 0, 1, 2, false, new lib.button1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button1).wait(179));

	// outline
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,0,3).p("EgXbgu3MAu3AAAMAAABdvMgu3AAAg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(179));

	// Layer_35
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1.5,1,1).p("ACIAAQAAA4goAoQgoAog4AAQg3AAgogoQgogoAAg4QAAg4AogoQAogoA3AAQA4AAAoAoQAoAoAAA4g");
	this.shape_1.setTransform(279.75,532.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWAmQgJgIAAgMQAAgHADgGQAEgFAHgDQgGgDgDgEQgDgFAAgGQAAgJAHgHQAGgGANAAQALAAAHAGQAGAHAAAJQAAAGgDAFQgDAEgFADQAHADADAEQAEAGAAAHQAAAMgHAHQgIAIgMAAQgLAAgIgGgAgMAHQgDAEAAAFQAAAHADAEQAEAEAFAAQAEAAADgEQAEgEAAgHQAAgGgEgDQgDgEgEAAQgGAAgDAEgAgLgbQgDADAAAEQAAAFADADQADADAFAAQADAAADgDQADgDAAgFQAAgEgDgDQgDgDgDAAQgFAAgDADgAhIAqIAAg9QgJAJgMAEIAAgPQAGgCAIgGQAHgGADgIIANAAIAABVgAA5AeIAAgWIgXAAIAAgPIAXAAIAAgWIAPAAIAAAWIAWAAIAAAPIgWAAIAAAWg");
	this.shape_2.setTransform(280.075,532.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("APsChIAFgLIADgKIABgKIABgKQAAgKgCgKQgCgJgGgNIAIAAQAHAJADALQAEAKAAALQAAAJgDAKQgDAMgIALgAGIChQgHgKgEgKQgDgLAAgKQAAgNAEgLQAEgKAGgIIAIAAQgGANgCAJQgCAKAAAKIABAPIAEAOIAFAMgAPCCLQgFgFgBgIIAMgBQAAAEADADQADACADAAQAEAAACgDQADgDAAgGQAAgGgDgDQgCgDgEAAQgGAAgEAFIgKgCIAGghIAhAAIAAALIgXAAIgCALQAEgCAEAAQAIAAAGAGQAGAGAAAJQAAAIgFAGQgGAJgLAAQgJAAgGgFgAORCIQgGgHAAgRQAAgSAGgHQAGgIALAAQAHAAAFAEQAFAEABAIIgMABQAAgEgCgBQgBgBAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAQgEAAgCADQgDAEgBALQAFgGAHAAQAHAAAGAGQAFAGAAAJQAAAKgGAGQgFAGgJAAQgKAAgGgIgAObBxQgDADAAAFQAAAGADADQADAEADAAQAEAAACgDQACgDAAgGQAAgGgCgDQgDgDgDAAQgEAAgCADgANgCLQgFgFgBgIIAMgBQAAAEADADQADACADAAQAEAAACgDQADgDAAgGQAAgGgDgDQgCgDgEAAQgGAAgEAFIgKgCIAGghIAhAAIAAALIgXAAIgCALQAEgCAEAAQAIAAAGAGQAGAGAAAJQAAAIgFAGQgGAJgLAAQgJAAgGgFgAMvCIQgGgHAAgRQAAgSAGgHQAGgIALAAQAHAAAFAEQAFAEABAIIgMABQAAgEgCgBQgBgBAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAQgEAAgCADQgDAEgBALQAFgGAHAAQAHAAAGAGQAFAGAAAJQAAAKgGAGQgFAGgJAAQgKAAgGgIgAM5BxQgDADAAAFQAAAGADADQADAEADAAQAEAAACgDQACgDAAgGQAAgGgCgDQgDgDgDAAQgEAAgCADgAIvCJQgGgHAAgTQAAgSAHgIQAFgGAJAAQAJAAAGAGQAGAIAAASQAAASgGAIQgGAHgJAAQgJAAgGgHgAI6BaQgCACAAADQgCAFAAALIABAQIADAFQABABAAAAQAAAAABAAQAAABABAAQABAAAAAAIAEgCIADgFQABgEAAgMQAAgLgBgEIgDgGIgEgBQAAAAgBAAQgBAAAAAAQgBAAAAABQAAAAgBAAgAH+CJQgGgHAAgTQAAgSAHgIQAFgGAJAAQAJAAAGAGQAGAIAAASQAAASgGAIQgGAHgJAAQgJAAgGgHgAIJBaQgCACAAADQgCAFAAALIABAQIADAFQABABAAAAQABAAAAAAQABABAAAAQABAAAAAAIAEgCIADgFQABgEAAgMQAAgLgBgEQgBgEgCgCIgEgBQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAgAHOCLQgHgFAAgJQAAgGADgEQACgEAGgDQgFgCgCgDQgCgEAAgEQAAgHAFgFQAFgEAJAAQAJAAAFAEQAFAFAAAHQAAAFgCADQgCAEgFABQAGADADAEQACAEAAAFQAAAJgFAFQgGAGgJAAQgJAAgGgFgAHWB1QgDADAAADQAAAFADADQADADADAAQAEAAADgDQACgCAAgGQAAgEgCgDQgDgCgEAAQgEAAgCADgAHXBbQgCACAAADQAAAEACACQACACADAAQAEAAACgCQACgCAAgEQAAgDgCgCQgCgDgEAAQgDAAgCADgAGcCJQgGgHAAgTQAAgSAHgIQAFgGAJAAQAJAAAGAGQAGAIAAASQAAASgGAIQgGAHgJAAQgJAAgGgHgAGnBaQgCACAAADQgCAFAAALIABAQIADAFQABABAAAAQABAAAAAAQABABAAAAQABAAAAAAIAEgCIADgFQABgEAAgMQAAgLgBgEIgDgGIgEgBQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAgADkCHQgIgJAAgPQAAgJADgHQACgFADgEQAEgEAFgCQAGgCAHAAQAPAAAIAJQAIAIAAAQQAAAPgIAJQgIAJgOAAQgPAAgIgJgADuBeQgFAGAAALQAAALAFAFQAFAGAIAAQAHAAAFgGQAFgFAAgLQAAgLgFgGQgEgFgIAAQgIAAgFAFgABfCHQgIgJAAgPQAAgJADgHQACgFADgEQAEgEAFgCQAGgCAHAAQAPAAAIAJQAIAIAAAQQAAAPgIAJQgIAJgOAAQgPAAgIgJgABpBeQgFAGAAALQAAALAFAFQAFAGAIAAQAHAAAFgGQAFgFAAgLQAAgLgFgGQgEgFgIAAQgIAAgFAFgALjCPQAAgNAFgOQAFgOAJgLIgcAAIAAgLIAqAAIAAAJQgFAFgGAJQgFAKgDALQgDAKAAAJgAKyCPQAAgNAFgOQAFgOAJgLIgcAAIAAgLIAqAAIAAAJQgFAFgGAJQgFAKgDALQgDAKAAAJgAKLCPIAAguQgHAGgJADIAAgLQAFgCAGgEQAFgEACgGIAKAAIAABAgAFMCPIgRgeIgLAKIAAAUIgNAAIAAhAIANAAIAAAcIAagcIASAAIgYAZIAZAngADHCPIgRgeIgLAKIAAAUIgNAAIAAhAIANAAIAAAcIAagcIASAAIgYAZIAZAngABDCPIgJgOIgHgJIgEgDIgGgBIgDAAIAAAbIgNAAIAAhAIAbAAQALAAAEACQAFABADAFQACAEAAAGQAAAHgEAFQgEAEgIACIAGAFIAIAKIAIANgAAmBqIAKAAIALgBIAEgCQABgCAAgDQAAgDgCgCQgBgCgDgBIgUAAgAghCPIAAhAIAuAAIAAALIghAAIAAAOIAfAAIAAALIgfAAIAAARIAjAAIAAALgAg5CPIAAgyIgNAyIgMAAIgNgyIAAAyIgMAAIAAhAIATAAIAMArIALgrIAUAAIAABAgAicCPIAAhAIANAAIAABAgAjDCPIAAg1IgTAAIAAgLIAyAAIAAALIgTAAIAAA1gAjsCPIgagqIAAAqIgMAAIAAhAIANAAIAaArIAAgrIAMAAIAABAgAlNCPIAAhAIAvAAIAAALIgiAAIAAAOIAgAAIAAALIggAAIAAARIAkAAIAAALgAlnCPIAAgcIgZAAIAAAcIgNAAIAAhAIANAAIAAAZIAZAAIAAgZIANAAIAABAgAmjCPIgJgOIgHgJIgEgDIgGgBIgDAAIAAAbIgNAAIAAhAIAbAAQALAAAEACQAFABADAFQACAEAAAGQAAAHgEAFQgEAEgIACIAGAFIAIAKIAIANgAnABqIAKAAIALgBIAEgCQABgCAAgDQAAgDgCgCQgBgCgDgBIgUAAgAoICPIAAhAIAvAAIAAALIgiAAIAAAOIAgAAIAAALIggAAIAAARIAkAAIAAALgApIBPIAaAAIALABQAEAAADACQADACACAEQACADAAAEQAAAFgDADQgCAEgEACQAFACAEAEQADAEAAAFQAAAFgCAEQgCAEgEACQgDADgGAAIglABgAo7CEIAMAAIAJAAQADgBACgCQABgCAAgDQAAgDgBgCQgBgCgDgBQgDgBgIAAIgLAAgAo7BoIASAAQADAAACgCQACgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQgBgCgDAAIgTAAgAp7CPIgZgqIAAAqIgMAAIAAhAIAMAAIAaArIAAgrIAMAAIAABAgAq1CPIgFgPIgaAAIgFAPIgOAAIAZhAIAOAAIAZBAgAq/B2IgIgYIgJAYIARAAgAr7CPIgZgqIAAAqIgMAAIAAhAIAMAAIAaArIAAgrIAMAAIAABAgAs1CPIgFgPIgaAAIgFAPIgOAAIAZhAIAOAAIAZBAgAs/B2IgIgYIgJAYIARAAgAuDCPIAAgbIgXglIAPAAIAPAZIAPgZIAPAAIgYAlIAAAbgAugCPIgFgPIgaAAIgFAPIgOAAIAZhAIAOAAIAZBAgAuqB2IgIgYIgJAYIARAAgAwBCPIAAg/IANAAIAAA0IAgAAIAAALgAMMB+IAAgMIAYAAIAAAMgAJcB+IAAgMIAYAAIAAAMgAEmAQQgIgJAAgOQAAgKADgHQACgEADgEQAEgEAFgCQAGgDAHAAQAPAAAIAJQAIAJAAAPQAAAPgIAJQgIAIgOAAQgPAAgIgIgAEwgYQgFAFAAALQAAAKAFAGQAFAFAIAAQAHAAAFgFQAFgGAAgKQAAgLgFgFQgEgGgIAAQgIAAgFAGgAChAQQgIgJAAgOQAAgKADgHQACgEADgEQAEgEAFgCQAGgDAHAAQAPAAAIAJQAIAJAAAPQAAAPgIAJQgIAIgOAAQgPAAgIgIgACrgYQgFAFAAALQAAAKAFAGQAFAFAIAAQAHAAAFgFQAFgGAAgKQAAgLgFgFQgEgGgIAAQgIAAgFAGgABjAUQgIgEgDgIQgEgIAAgIQAAgKAEgIQAEgHAIgEQAHgEAJAAQAMAAAGAFQAHAFACAJIgNADQgBgFgEgDQgEgDgFAAQgJAAgFAGQgFAFAAALQAAAKAFAGQAFAFAJAAIAIgBIAHgEIAAgIIgPAAIAAgKIAcAAIAAAYQgEAEgIADQgIADgIAAQgKAAgHgEgAAeAUQgIgEgDgIQgEgIAAgIQAAgKAEgIQAEgHAIgEQAHgEAJAAQAMAAAGAFQAHAFACAJIgNADQgBgFgEgDQgEgDgFAAQgJAAgFAGQgFAFAAALQAAAKAFAGQAFAFAJAAIAIgBIAHgEIAAgIIgPAAIAAgKIAcAAIAAAYQgEAEgIADQgIADgIAAQgKAAgHgEgAIlAXIAAgMIAMAAIAAAMgAILAXIgagoIAAAoIgMAAIAAg+IANAAIAaApIAAgpIAMAAIAAA+gAHRAXIgGgOIgZAAIgGAOIgNAAIAZg+IANAAIAaA+gAHHgBIgJgYIgIAYIARAAgAGOAXIgRgdIgLAKIAAATIgNAAIAAg+IANAAIAAAcIAagcIASAAIgYAYIAZAmgAEKAXIgJgOIgHgJIgEgCIgGAAIgDAAIAAAZIgNAAIAAg+IAbAAQALAAAEABQAFACADAEQACAFAAAFQAAAIgEAEQgEAFgIABIAGAEIAIALIAIAMgADtgNIAKAAIALAAIAEgDQABgCAAgDQAAgDgCgCQgBgCgDAAIgUgBgAgIAXIgagoIAAAoIgMAAIAAg+IANAAIAaApIAAgpIALAAIAAA+gAhpAXIAAg+IAvAAIAAAKIgiAAIAAAOIAgAAIAAALIggAAIAAARIAkAAIAAAKgAiQAXIAAg0IgTAAIAAgKIAyAAIAAAKIgTAAIAAA0gAjNAXIgKgOIgGgJIgEgCIgHAAIgCAAIAAAZIgNAAIAAg+IAbAAQAKAAAFABQAEACADAEQADAFAAAFQAAAIgEAEQgFAFgIABIAHAEIAHALIAIAMgAjqgNIAJAAIAMAAIADgDQACgCAAgDQAAgDgCgCQgCgCgDAAIgTgBgAkyAXIAAg+IAvAAIAAAKIgiAAIAAAOIAgAAIAAALIggAAIAAARIAjAAIAAAKgAlJAXIgSgdIgKAKIAAATIgNAAIAAg+IANAAIAAAcIAagcIARAAIgYAYIAZAmgAmNAXIgZgoIAAAoIgMAAIAAg+IAMAAIAaApIAAgpIAMAAIAAA+gAnHAXIgFgOIgaAAIgFAOIgOAAIAZg+IAOAAIAZA+gAnRgBIgIgYIgJAYIARAAgAoJAXIgSgdIgKAKIAAATIgNAAIAAg+IANAAIAAAcIAagcIARAAIgYAYIAZAmgABHhWQAEgBACgCQABgDAAgDIgGAAIAAgMIANAAIAAAIIgBAJQgBADgDACQgCADgEABgAB+hkQgGgFgCgLIANgBQABAGAEADQADADAGAAQAGAAADgDQADgCAAgEIgBgEIgFgCIgKgDQgKgDgEgDQgGgGAAgHQAAgFADgEQACgFAGgCQAFgCAHAAQAMAAAGAFQAGAFAAAJIgMABQgBgFgDgCQgDgCgFAAQgGAAgDACQAAAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAAAAAABQAAABABAAQAAABAAAAQAAAAABABQACACAKACQAJACAFADQAEACADAEQACAEAAAGQAAAGgDAEQgDAFgFADQgGACgIAAQgMAAgHgGgAg1hnQgJgJAAgPQAAgJADgHQACgFAEgEQAEgEAEgCQAGgCAIAAQAOAAAIAJQAJAIAAAQQAAAPgIAJQgJAJgOAAQgOAAgIgJgAgsiQQgFAGAAALQAAALAFAFQAFAGAIAAQAIAAAFgGQAFgFAAgLQAAgLgFgGQgFgFgIAAQgIAAgFAFgAi6hnQgJgJAAgPQAAgJADgHQACgFAEgEQAEgEAEgCQAGgCAIAAQAOAAAIAJQAJAIAAAQQAAAPgIAJQgJAJgOAAQgOAAgIgJgAixiQQgFAGAAALQAAALAFAFQAFAGAIAAQAIAAAFgGQAFgFAAgLQAAgLgFgGQgFgFgIAAQgIAAgFAFgAMMhfIgFgPIgaAAIgFAPIgOAAIAZhAIAOAAIAZBAgAMCh4IgIgYIgJAYIARAAgALGhfIgZgqIAAAqIgMAAIAAhAIAMAAIAaArIAAgrIAMAAIAABAgAJmhfIAAhAIAvAAIAAALIgiAAIAAAOIAgAAIAAALIggAAIAAARIAjAAIAAALgAJPhfIgSgeIgKAKIAAAUIgNAAIAAhAIANAAIAAAcIAagcIARAAIgYAZIAZAngAIQhfIgKgOIgGgJIgEgDIgHgBIgCAAIAAAbIgNAAIAAhAIAbAAQAKAAAFACQAEABADAFQADAEAAAGQAAAHgEAFQgFAEgIACIAHAFIAHAKIAIANgAHziEIAJAAIAMgBIADgCQACgCAAgDQAAgDgCgCQgCgCgDgBIgTAAgAGrhfIAAhAIAvAAIAAALIgiAAIAAAOIAgAAIAAALIggAAIAAARIAjAAIAAALgAGDhfIAAg1IgTAAIAAgLIAzAAIAAALIgTAAIAAA1gAFLhfIgFgPIgaAAIgFAPIgOAAIAZhAIAOAAIAZBAgAFBh4IgIgYIgJAYIARAAgAD9hfIAAgbIgXglIAPAAIAPAZIAPgZIAPAAIgYAlIAAAbgADghfIgFgPIgaAAIgFAPIgOAAIAZhAIAOAAIAZBAgADWh4IgIgYIgJAYIARAAgAAyhfIgSgeIgKAKIAAAUIgNAAIAAhAIANAAIAAAcIAagcIARAAIgYAZIAZAngAhShfIgSgeIgKAKIAAAUIgNAAIAAhAIANAAIAAAcIAagcIARAAIgYAZIAZAngAjWhfIgKgOIgGgJIgEgDIgHgBIgCAAIAAAbIgNAAIAAhAIAbAAQAKAAAFACQAEABADAFQADAEAAAGQAAAHgEAFQgFAEgIACIAHAFIAHAKIAIANgAjziEIAJAAIAMgBIADgCQACgCAAgDQAAgDgCgCQgCgCgDgBIgTAAgAk7hfIAAhAIAvAAIAAALIgiAAIAAAOIAgAAIAAALIggAAIAAARIAjAAIAAALgAlUhfIAAgyIgNAyIgMAAIgMgyIAAAyIgMAAIAAhAIATAAIALArIAMgrIATAAIAABAgAmvhfIgFgPIgaAAIgFAPIgOAAIAZhAIAOAAIAZBAgAm5h4IgIgYIgJAYIARAAgAn1hfIgZgqIAAAqIgMAAIAAhAIAMAAIAaArIAAgrIAMAAIAABAgApVhfIAAhAIAvAAIAAALIgiAAIAAAOIAgAAIAAALIggAAIAAARIAjAAIAAALgAprhfIgKgOIgGgJIgEgDIgHgBIgCAAIAAAbIgNAAIAAhAIAbAAQAKAAAFACQAEABADAFQADAEAAAGQAAAHgEAFQgFAEgIACIAHAFIAHAKIAIANgAqIiEIAJAAIAMgBIADgCQACgCAAgDQAAgDgCgCQgCgCgDgBIgTAAgAqqhfIgFgPIgaAAIgFAPIgOAAIAZhAIAOAAIAZBAgAq0h4IgIgYIgJAYIARAAgArshfIgSgeIgKAKIAAAUIgNAAIAAhAIANAAIAAAcIAagcIARAAIgYAZIAZAng");
	this.shape_3.setTransform(195.425,571.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgTA5QgOgJgIgPQgHgPAAgSQAAgTAIgPQAJgPAPgIQAMgHARAAQAYAAANAKQANAKAEARIgZAFQgDgJgHgGQgIgFgLAAQgPAAgKAKQgKALAAAVQAAAVAKALQAKALAPAAQAIAAAIgDQAIgDAGgEIAAgQIgdAAIAAgUIA2AAIAAAwQgIAIgPAGQgPAGgPAAQgTAAgPgIgAIqA/IAAgYIAYAAIAAAYgAHyA/IgyhRIAABRIgYAAIAAh9IAZAAIAzBTIAAhTIAYAAIAAB9gAF/A/IgLgdIgyAAIgKAdIgbAAIAxh9IAbAAIAyB9gAFsANIgRgtIgRAtIAiAAgADpA/IAAhnIglAAIAAgWIBjAAIAAAWIglAAIAABngACxA/IgLgdIgyAAIgKAdIgbAAIAxh9IAaAAIAyB9gACeANIgRgtIgRAtIAiAAgAhfA/IgzhRIAABRIgXAAIAAh9IAYAAIA0BTIAAhTIAXAAIAAB9gAjbA/IAAh9IAaAAIAAB9gAkGA/IgSgcIgNgSQgEgEgEgBQgEgCgJAAIgFAAIAAA1IgZAAIAAh9IA1AAQAUAAAKAEQAJADAFAJQAGAIAAAMQAAAOgJAJQgIAIgRACQAJAFAFAGQAFAGAJAOIAQAZgAk/gJIATAAQASAAAFgBQAEgCADgDQACgEAAgGQAAgGgDgEQgDgEgGgBIgnAAgAnNA/IAAh9IBdAAIAAAWIhDAAIAAAbIA/AAIAAAVIg/AAIAAAiIBGAAIAAAVgApBA/IAAh9IApAAQAXAAAHACQAKADAIAKQAHAJAAAPQAAAMgEAHQgEAHgHAFQgGAEgHACQgJABgRAAIgRAAIAAAwgAoogFIAOAAQAPAAAFgCQAFgCADgEQADgEAAgGQAAgGgEgFQgEgEgGgBQgFgBgOAAIgMAAgAIqgDIAAgYIAYAAIAAAYg");
	this.shape_4.setTransform(195.325,531.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AxsHFIAAuJMAjZAAAIAAOJg");
	this.shape_5.setTransform(204.825,555.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(179));

	// Layer_31
	this.instance = new lib.GHW();
	this.instance.setTransform(0,510);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(179));

	// Layer_37
	this.instance_1 = new lib.Symbol14();
	this.instance_1.setTransform(252.5,524,1,1,0,0,0,9.5,10);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(126).to({_off:false},0).wait(1).to({regY:9.9,scaleX:0.9774,scaleY:0.9774,x:249.6,y:513.65},0).wait(1).to({scaleX:0.9549,scaleY:0.9548,x:246.7,y:503.4},0).wait(1).to({scaleX:0.9323,scaleY:0.9322,x:243.85,y:493.15},0).wait(1).to({scaleX:0.9098,scaleY:0.9095,x:241,y:482.9},0).wait(1).to({scaleX:0.8872,scaleY:0.8869,x:238.15,y:482},0).wait(1).to({scaleX:0.8647,scaleY:0.8643,x:235.25,y:481.1},0).wait(1).to({scaleX:0.8421,scaleY:0.8417,x:232.45,y:480.25},0).wait(1).to({x:235.3,y:481.15},0).wait(1).to({x:238.15,y:482},0).wait(1).to({x:241,y:482.9},0).wait(43));

	// BUTTON
	this.instance_2 = new lib.Symbol13();
	this.instance_2.setTransform(150.35,462.75,0.1755,0.175,0,0,0,104.2,21.4);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(118).to({_off:false},0).wait(1).to({regX:102.5,regY:20.1,scaleX:0.4503,scaleY:0.45,x:149.65,y:462.05},0).wait(1).to({scaleX:0.7252,scaleY:0.725,x:149.3,y:461.55},0).wait(1).to({scaleX:1,scaleY:1,x:148.9,y:461.1},0).wait(10).to({scaleX:0.9754,scaleY:0.9743,x:149.25},0).wait(1).to({scaleX:0.9507,scaleY:0.9487,x:149.65},0).wait(1).to({scaleX:0.9261,scaleY:0.923,x:150,y:461.15},0).wait(1).to({scaleX:0.9507,scaleY:0.9487,x:149.65,y:461.1},0).wait(1).to({scaleX:0.9754,scaleY:0.9743,x:149.25},0).wait(1).to({scaleX:1,scaleY:1,x:148.9},0).wait(43));

	// E_
	this.instance_3 = new lib.Tween10("synched",0);
	this.instance_3.setTransform(231.65,184.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(114).to({_off:false},0).to({alpha:1},3).wait(62));

	// N
	this.instance_4 = new lib.Tween9("synched",0);
	this.instance_4.setTransform(165.55,182.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(113).to({_off:false},0).to({alpha:1},3).wait(63));

	// H_
	this.instance_5 = new lib.Tween8("synched",0);
	this.instance_5.setTransform(117.65,185.35);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(114).to({_off:false},0).to({alpha:1},3).wait(62));

	// R
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(68.8,183.85);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(112).to({_off:false},0).to({alpha:1},3).wait(64));

	// Q
	this.instance_7 = new lib.Tween6("synched",0);
	this.instance_7.setTransform(192.9,184.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(112).to({_off:false},0).to({alpha:1},3).wait(64));

	// C
	this.instance_8 = new lib.Tween5("synched",0);
	this.instance_8.setTransform(96.05,184.7);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(111).to({_off:false},0).to({alpha:1},3).wait(65));

	// U
	this.instance_9 = new lib.Tween4("synched",0);
	this.instance_9.setTransform(211.4,184.6);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(111).to({_off:false},0).to({alpha:1},3).wait(65));

	// U
	this.instance_10 = new lib.Tween3("synched",0);
	this.instance_10.setTransform(146.65,183.95);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(110).to({_off:false},0).to({alpha:1},3).wait(66));

	// I
	this.instance_11 = new lib.Tween2("synched",0);
	this.instance_11.setTransform(179.4,184.7);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(110).to({_off:false},0).to({alpha:1},3).wait(66));

	// I
	this.instance_12 = new lib.Tween1("synched",0);
	this.instance_12.setTransform(82.8,195.95);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(110).to({_off:false},0).to({alpha:1},3).wait(66));

	// Layer_19
	this.instance_13 = new lib.Symbol12();
	this.instance_13.setTransform(150.45,90.65,0.3332,0.333,0,0,0,91.4,65.3);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(103).to({_off:false},0).wait(1).to({regX:90,regY:65.8,scaleX:0.6666,scaleY:0.6665,x:150.65,y:88.55},0).wait(1).to({scaleX:1,scaleY:1,x:151.3,y:86.3},0).wait(74));

	// Layer_14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_51 = new cjs.Graphics().p("AzDFPIAAqdMAmIAAAIAAKdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(51).to({graphics:mask_graphics_51,x:199.05,y:147.525}).wait(128));

	// Layer_13
	this.instance_14 = new lib.Symbol11();
	this.instance_14.setTransform(25.5,147.5,1,1,0,0,0,106.5,33.5);
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(51).to({_off:false},0).wait(1).to({x:59.5},0).wait(1).to({x:89.5},0).wait(1).to({x:120.5},0).wait(1).to({x:148.5},0).wait(1).to({x:183.5},0).wait(39).to({alpha:0.8},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0},0).wait(80));

	// Layer_18 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_37 = new cjs.Graphics().p("AvtFyIAArjIfbAAIAALjg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(37).to({graphics:mask_1_graphics_37,x:86.575,y:90.025}).wait(142));

	// Layer_12
	this.instance_15 = new lib.Symbol10();
	this.instance_15.setTransform(284,88.5,1,1,0,0,0,93,35.5);
	this.instance_15._off = true;

	var maskedShapeInstanceList = [this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(37).to({_off:false},0).wait(1).to({x:239},0).wait(1).to({x:208},0).wait(1).to({x:182},0).wait(1).to({x:154},0).wait(1).to({x:126},0).wait(1).to({x:95},0).wait(52).to({alpha:0.8},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0},0).wait(80));

	// Talent
	this.instance_16 = new lib.Symbol5();
	this.instance_16.setTransform(56.5,307.1,1.0219,1.0638,0,0,0,178.6,188.5);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(24).to({_off:false},0).wait(1).to({regX:182.5,regY:188,scaleX:1.0187,scaleY:1.0602,x:61.05,y:306.7},0).wait(1).to({scaleX:1.0155,scaleY:1.0567,x:61.6,y:306.8},0).wait(1).to({scaleX:1.0122,scaleY:1.0531,x:62.2,y:307},0).wait(1).to({scaleX:1.009,scaleY:1.0496,x:62.75,y:307.1},0).wait(1).to({scaleX:1.0058,scaleY:1.046,x:63.3,y:307.25},0).wait(1).to({scaleX:1.0026,scaleY:1.0425,x:63.8,y:307.45},0).wait(1).to({scaleX:0.9994,scaleY:1.0389,x:64.4,y:307.55},0).wait(1).to({scaleX:0.9962,scaleY:1.0354,x:64.95,y:307.7},0).wait(1).to({scaleX:0.9929,scaleY:1.0318,x:65.5,y:307.9},0).wait(1).to({scaleX:0.9897,scaleY:1.0283,x:66.05,y:308},0).wait(1).to({scaleX:0.9865,scaleY:1.0247,x:66.6,y:308.2},0).wait(1).to({scaleX:0.9833,scaleY:1.0212,x:67.15,y:308.35},0).wait(1).to({scaleX:0.9801,scaleY:1.0176,x:67.7,y:308.45},0).wait(1).to({scaleX:0.9768,scaleY:1.0141,x:68.25,y:308.65},0).wait(1).to({scaleX:0.9736,scaleY:1.0105,x:68.85,y:308.75},0).wait(1).to({scaleX:0.9704,scaleY:1.007,x:69.35,y:308.9},0).wait(1).to({scaleX:0.9672,scaleY:1.0034,x:69.9,y:309.1},0).wait(1).to({scaleX:0.964,scaleY:0.9999,x:70.45,y:309.2},0).wait(1).to({scaleX:0.9608,scaleY:0.9963,x:71.05,y:309.35},0).wait(1).to({scaleX:0.9575,scaleY:0.9927,x:71.6,y:309.55},0).wait(1).to({scaleX:0.9543,scaleY:0.9892,x:72.1,y:309.65},0).wait(1).to({scaleX:0.9511,scaleY:0.9856,x:72.65,y:309.85},0).wait(1).to({scaleX:0.9479,scaleY:0.9821,x:73.25,y:310},0).wait(1).to({scaleX:0.9447,scaleY:0.9785,x:73.8,y:310.1},0).wait(1).to({scaleX:0.9414,scaleY:0.975,x:74.35,y:310.3},0).wait(1).to({scaleX:0.9382,scaleY:0.9714,x:74.9,y:310.45},0).wait(1).to({scaleX:0.935,scaleY:0.9679,x:75.45,y:310.55},0).wait(1).to({scaleX:0.9318,scaleY:0.9643,x:76,y:310.75},0).wait(1).to({scaleX:0.9286,scaleY:0.9608,x:76.55,y:310.85},0).wait(1).to({scaleX:0.9254,scaleY:0.9572,x:77.1,y:311},0).wait(1).to({scaleX:0.9221,scaleY:0.9537,x:77.7,y:311.2},0).wait(1).to({scaleX:0.9189,scaleY:0.9501,x:78.2,y:311.3},0).wait(1).to({scaleX:0.9157,scaleY:0.9466,x:78.75,y:311.5},0).wait(1).to({scaleX:0.9125,scaleY:0.943,x:79.35,y:311.65},0).wait(1).to({scaleX:0.9093,scaleY:0.9395,x:79.9,y:311.75},0).wait(1).to({scaleX:0.906,scaleY:0.9359,x:80.45,y:311.95},0).wait(1).to({scaleX:0.9028,scaleY:0.9324,x:80.95,y:312.1},0).wait(1).to({scaleX:0.8996,scaleY:0.9288,x:81.55,y:312.2},0).wait(1).to({scaleX:0.8964,scaleY:0.9253,x:82.1,y:312.4},0).wait(1).to({scaleX:0.8932,scaleY:0.9217,x:82.65,y:312.55},0).wait(1).to({scaleX:0.8899,scaleY:0.9181,x:83.2,y:312.65},0).wait(1).to({scaleX:0.8867,scaleY:0.9146,x:83.8,y:312.85},0).wait(1).to({scaleX:0.8835,scaleY:0.911,x:84.3,y:312.95},0).wait(1).to({scaleX:0.8803,scaleY:0.9075,x:84.85,y:313.15},0).wait(1).to({scaleX:0.8771,scaleY:0.9039,x:85.4,y:313.3},0).wait(1).to({scaleX:0.8739,scaleY:0.9004,x:86,y:313.4},0).wait(1).to({scaleX:0.8706,scaleY:0.8968,x:86.55,y:313.6},0).wait(1).to({scaleX:0.8674,scaleY:0.8933,x:87.05,y:313.75},0).wait(1).to({scaleX:0.8642,scaleY:0.8897,x:87.6,y:313.85},0).wait(1).to({scaleX:0.861,scaleY:0.8862,x:88.2,y:314.05},0).wait(1).to({scaleX:0.8578,scaleY:0.8826,x:88.75,y:314.2},0).wait(1).to({scaleX:0.8545,scaleY:0.8791,x:89.3,y:314.35},0).wait(1).to({scaleX:0.8513,scaleY:0.8755,x:89.8,y:314.5},0).wait(1).to({scaleX:0.8481,scaleY:0.872,x:90.4,y:314.65},0).wait(1).to({scaleX:0.8449,scaleY:0.8684,x:90.95,y:314.8},0).wait(1).to({scaleX:0.8417,scaleY:0.8649,x:91.5,y:314.95},0).wait(1).to({scaleX:0.8385,scaleY:0.8613,x:92.05,y:315.05},0).wait(1).to({scaleX:0.8352,scaleY:0.8578,x:92.6,y:315.25},0).wait(1).to({scaleX:0.832,scaleY:0.8542,x:93.15,y:315.4},0).wait(1).to({scaleX:0.8288,scaleY:0.8506,x:93.7,y:315.5},0).wait(1).to({scaleX:0.8256,scaleY:0.8471,x:94.25,y:315.7},0).wait(1).to({scaleX:0.8224,scaleY:0.8435,x:94.85,y:315.85},0).wait(1).to({scaleX:0.8191,scaleY:0.84,x:95.4,y:316},0).wait(1).to({scaleX:0.8159,scaleY:0.8364,x:95.9,y:316.15},0).wait(1).to({scaleX:0.8127,scaleY:0.8329,x:96.45,y:316.3},0).wait(1).to({scaleX:0.8095,scaleY:0.8293,x:97.05,y:316.45},0).wait(1).to({scaleX:0.8063,scaleY:0.8258,x:97.6,y:316.6},0).wait(1).to({scaleX:0.8031,scaleY:0.8222,x:98.15,y:316.75},0).wait(1).to({scaleX:0.7998,scaleY:0.8187,x:98.65,y:316.9},0).wait(1).to({scaleX:0.7966,scaleY:0.8151,x:99.25,y:317.05},0).wait(1).to({scaleX:0.7934,scaleY:0.8116,x:99.8,y:317.2},0).wait(1).to({scaleX:0.7902,scaleY:0.808,x:100.35,y:317.35},0).wait(1).to({scaleX:0.787,scaleY:0.8045,x:100.9,y:317.5},0).wait(1).to({scaleX:0.7837,scaleY:0.8009,x:101.45,y:317.65},0).wait(1).to({scaleX:0.7805,scaleY:0.7974,x:102,y:317.8},0).wait(1).to({scaleX:0.7773,scaleY:0.7938,x:102.55,y:317.95},0).wait(1).to({scaleX:0.7741,scaleY:0.7903,x:103.1,y:318.1},0).wait(1).to({scaleX:0.7709,scaleY:0.7867,x:103.7,y:318.25},0).wait(1).to({scaleX:0.7677,scaleY:0.7831,x:104.2,y:318.4},0).wait(1).to({scaleX:0.7644,scaleY:0.7796,x:104.75,y:318.55},0).wait(1).to({scaleX:0.7612,scaleY:0.776,x:105.3,y:318.7},0).wait(1).to({scaleX:0.758,scaleY:0.7725,x:105.9,y:318.85},0).wait(1).to({scaleX:0.7548,scaleY:0.7689,x:106.45,y:319},0).wait(1).to({scaleX:0.7516,scaleY:0.7654,x:107,y:319.15},0).wait(1).to({scaleX:0.7483,scaleY:0.7618,x:107.5,y:319.3},0).wait(1).to({scaleX:0.7451,scaleY:0.7583,x:108.1,y:319.45},0).wait(1).to({scaleX:0.7419,scaleY:0.7547,x:108.65,y:319.6},0).wait(1).to({scaleX:0.7387,scaleY:0.7512,x:109.2,y:319.75},0).wait(1).to({scaleX:0.7355,scaleY:0.7476,x:109.75,y:319.9},0).wait(1).to({scaleX:0.7323,scaleY:0.7441,x:110.3,y:320.05},0).wait(1).to({scaleX:0.729,scaleY:0.7405,x:110.85,y:320.2},0).wait(1).to({scaleX:0.7258,scaleY:0.737,x:111.4,y:320.35},0).wait(1).to({scaleX:0.7226,scaleY:0.7334,x:111.95,y:320.5},0).wait(1).to({scaleX:0.7194,scaleY:0.7299,x:112.55,y:320.65},0).wait(1).to({scaleX:0.7162,scaleY:0.7263,x:113.05,y:320.8},0).wait(1).to({scaleX:0.7129,scaleY:0.7228,x:113.6,y:321},0).wait(1).to({scaleX:0.7097,scaleY:0.7192,x:114.15,y:321.1},0).wait(1).to({scaleX:0.7065,scaleY:0.7157,x:114.75,y:321.25},0).wait(1).to({scaleX:0.7033,scaleY:0.7121,x:115.3,y:321.4},0).wait(1).to({scaleX:0.7001,scaleY:0.7085,x:115.8,y:321.55},0).wait(1).to({scaleX:0.6969,scaleY:0.705,x:116.35,y:321.7},0).wait(1).to({scaleX:0.6936,scaleY:0.7014,x:116.95,y:321.85},0).wait(1).to({scaleX:0.6904,scaleY:0.6979,x:117.5,y:322},0).wait(1).to({scaleX:0.6872,scaleY:0.6943,x:118.05,y:322.2},0).wait(1).to({scaleX:0.684,scaleY:0.6908,x:118.65,y:322.3},0).wait(1).to({scaleX:0.6808,scaleY:0.6872,x:119.15,y:322.45},0).wait(1).to({scaleX:0.6775,scaleY:0.6837,x:119.7,y:322.65},0).wait(1).to({scaleX:0.6743,scaleY:0.6801,x:120.25,y:322.75},0).wait(1).to({scaleX:0.6711,scaleY:0.6766,x:120.85,y:322.9},0).wait(1).to({scaleX:0.6679,scaleY:0.673,x:121.4,y:323.1},0).wait(1).to({scaleX:0.6647,scaleY:0.6695,x:121.85,y:323.2},0).wait(1).to({scaleX:0.6615,scaleY:0.6659,x:122.4,y:323.35},0).wait(1).to({scaleX:0.6582,scaleY:0.6624,x:122.95,y:323.5},0).wait(1).to({scaleX:0.655,scaleY:0.6588,x:123.55,y:323.65},0).wait(1).to({scaleX:0.6518,scaleY:0.6553,x:124.1,y:323.85},0).wait(1).to({scaleX:0.6486,scaleY:0.6517,x:124.6,y:323.95},0).wait(1).to({scaleX:0.6454,scaleY:0.6482,x:125.2,y:324.1},0).wait(1).to({scaleX:0.6421,scaleY:0.6446,x:125.75,y:324.3},0).wait(1).to({scaleX:0.6389,scaleY:0.641,x:126.3,y:324.4},0).wait(1).to({scaleX:0.6357,scaleY:0.6375,x:126.85,y:324.55},0).wait(1).to({scaleX:0.6325,scaleY:0.6339,x:127.4,y:324.75},0).wait(1).to({scaleX:0.6293,scaleY:0.6304,x:127.95,y:324.85},0).wait(1).to({scaleX:0.626,scaleY:0.6268,x:128.5,y:325},0).wait(1).to({scaleX:0.6228,scaleY:0.6233,x:129.05,y:325.2},0).wait(1).to({scaleX:0.6196,scaleY:0.6197,x:129.65,y:325.3},0).wait(1).to({scaleX:0.6164,scaleY:0.6162,x:130.2,y:325.5},0).wait(29));

	// Awan
	this.instance_17 = new lib.Symbol7();
	this.instance_17.setTransform(151,158,1,1,0,0,0,150,158);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(24).to({_off:false},0).wait(1).to({scaleX:1.005,scaleY:1.005,x:150.95,y:156.9},0).wait(1).to({scaleX:1.0099,scaleY:1.0099,x:151,y:155.75},0).wait(1).to({scaleX:1.0149,scaleY:1.0149,y:154.65},0).wait(1).to({scaleX:1.0199,scaleY:1.0199,y:153.55},0).wait(1).to({scaleX:1.0249,scaleY:1.0249,y:152.45},0).wait(1).to({scaleX:1.0298,scaleY:1.0298,x:150.95,y:151.3},0).wait(1).to({scaleX:1.0348,scaleY:1.0348,y:150.2},0).wait(1).to({scaleX:1.0398,scaleY:1.0398,y:149.1},0).wait(1).to({scaleX:1.0448,scaleY:1.0448,y:147.95},0).wait(1).to({scaleX:1.0497,scaleY:1.0497,y:146.8},0).wait(1).to({scaleX:1.0547,scaleY:1.0547,y:145.7},0).wait(1).to({scaleX:1.0597,scaleY:1.0597,y:144.6},0).wait(1).to({scaleX:1.0647,scaleY:1.0646,y:143.45},0).wait(1).to({scaleX:1.0696,scaleY:1.0696,y:142.35},0).wait(1).to({scaleX:1.0746,scaleY:1.0746,y:141.25},0).wait(1).to({scaleX:1.0796,scaleY:1.0796,y:140.1},0).wait(1).to({scaleX:1.0846,scaleY:1.0845,y:139},0).wait(1).to({scaleX:1.0895,scaleY:1.0895,y:137.9},0).wait(1).to({scaleX:1.0945,scaleY:1.0945,x:150.9,y:136.8},0).wait(1).to({scaleX:1.0995,scaleY:1.0995,y:135.6},0).wait(1).to({scaleX:1.1044,scaleY:1.1044,y:134.5},0).wait(1).to({scaleX:1.1094,scaleY:1.1094,y:133.4},0).wait(1).to({scaleX:1.1144,scaleY:1.1144,y:132.25},0).wait(1).to({scaleX:1.1194,scaleY:1.1193,y:131.15},0).wait(1).to({scaleX:1.1243,scaleY:1.1243,y:130.05},0).wait(1).to({scaleX:1.1293,scaleY:1.1293,y:128.95},0).wait(1).to({scaleX:1.1343,scaleY:1.1343,y:127.8},0).wait(1).to({scaleX:1.1393,scaleY:1.1392,y:126.7},0).wait(1).to({scaleX:1.1442,scaleY:1.1442,y:125.6},0).wait(1).to({scaleX:1.1492,scaleY:1.1492,y:124.4},0).wait(1).to({scaleX:1.1542,scaleY:1.1541,y:123.3},0).wait(1).to({scaleX:1.1592,scaleY:1.1591,x:150.85,y:122.2},0).wait(1).to({scaleX:1.1641,scaleY:1.1641,y:121.1},0).wait(1).to({scaleX:1.1691,scaleY:1.1691,y:119.95},0).wait(1).to({scaleX:1.1741,scaleY:1.174,y:118.85},0).wait(1).to({scaleX:1.1791,scaleY:1.179,y:117.75},0).wait(1).to({scaleX:1.184,scaleY:1.184,y:116.6},0).wait(1).to({scaleX:1.189,scaleY:1.189,y:115.5},0).wait(1).to({scaleX:1.194,scaleY:1.1939,y:114.4},0).wait(1).to({scaleX:1.1989,scaleY:1.1989,y:113.25},0).wait(1).to({scaleX:1.2039,scaleY:1.2039,y:112.1},0).wait(1).to({scaleX:1.2089,scaleY:1.2088,y:111},0).wait(1).to({scaleX:1.2139,scaleY:1.2138,y:109.9},0).wait(1).to({scaleX:1.2188,scaleY:1.2188,x:150.8,y:108.75},0).wait(1).to({scaleX:1.2238,scaleY:1.2238,y:107.65},0).wait(1).to({scaleX:1.2288,scaleY:1.2287,y:106.55},0).wait(1).to({scaleX:1.2338,scaleY:1.2337,y:105.45},0).wait(1).to({scaleX:1.2387,scaleY:1.2387,y:104.3},0).wait(1).to({scaleX:1.2437,scaleY:1.2437,y:103.15},0).wait(1).to({scaleX:1.2487,scaleY:1.2486,y:102.05},0).wait(1).to({scaleX:1.2537,scaleY:1.2536,y:100.9},0).wait(1).to({scaleX:1.2586,scaleY:1.2586,y:99.8},0).wait(1).to({scaleX:1.2636,scaleY:1.2635,y:98.7},0).wait(1).to({scaleX:1.2686,scaleY:1.2685,y:97.55},0).wait(1).to({scaleX:1.2736,scaleY:1.2735,y:96.45},0).wait(1).to({scaleX:1.2785,scaleY:1.2785,y:95.35},0).wait(1).to({scaleX:1.2835,scaleY:1.2834,x:150.75,y:94.25},0).wait(1).to({scaleX:1.2885,scaleY:1.2884,y:93.1},0).wait(1).to({scaleX:1.2934,scaleY:1.2934,y:91.95},0).wait(1).to({scaleX:1.2984,scaleY:1.2984,y:90.85},0).wait(1).to({scaleX:1.3034,scaleY:1.3033,y:89.7},0).wait(1).to({scaleX:1.3084,scaleY:1.3083,y:88.6},0).wait(1).to({scaleX:1.3133,scaleY:1.3133,y:87.5},0).wait(1).to({scaleX:1.3183,scaleY:1.3182,y:86.4},0).wait(1).to({scaleX:1.3233,scaleY:1.3232,y:85.25},0).wait(1).to({scaleX:1.3283,scaleY:1.3282,y:84.15},0).wait(1).to({scaleX:1.3332,scaleY:1.3332,y:83.05},0).wait(1).to({scaleX:1.3382,scaleY:1.3381,y:81.9},0).wait(1).to({scaleX:1.3432,scaleY:1.3431,y:80.75},0).wait(1).to({scaleX:1.3482,scaleY:1.3481,x:150.7,y:79.65},0).wait(1).to({scaleX:1.3531,scaleY:1.3531,y:78.55},0).wait(1).to({scaleX:1.3581,scaleY:1.358,y:77.4},0).wait(1).to({scaleX:1.3631,scaleY:1.363,y:76.3},0).wait(1).to({scaleX:1.3681,scaleY:1.368,y:75.2},0).wait(1).to({scaleX:1.373,scaleY:1.3729,y:74.05},0).wait(1).to({scaleX:1.378,scaleY:1.3779,y:72.95},0).wait(1).to({scaleX:1.383,scaleY:1.3829,y:71.85},0).wait(1).to({scaleX:1.3879,scaleY:1.3879,y:70.75},0).wait(1).to({scaleX:1.3929,scaleY:1.3928,y:69.55},0).wait(1).to({scaleX:1.3979,scaleY:1.3978,y:68.45},0).wait(1).to({scaleX:1.4029,scaleY:1.4028,y:67.35},0).wait(1).to({scaleX:1.4078,scaleY:1.4077,y:66.2},0).wait(1).to({scaleX:1.4128,scaleY:1.4127,x:150.65,y:65.1},0).wait(1).to({scaleX:1.4178,scaleY:1.4177,y:64},0).wait(1).to({scaleX:1.4228,scaleY:1.4227,y:62.9},0).wait(1).to({scaleX:1.4277,scaleY:1.4276,y:61.75},0).wait(1).to({scaleX:1.4327,scaleY:1.4326,y:60.65},0).wait(1).to({scaleX:1.4377,scaleY:1.4376,y:59.55},0).wait(1).to({scaleX:1.4427,scaleY:1.4426,y:58.35},0).wait(1).to({scaleX:1.4476,scaleY:1.4475,y:57.25},0).wait(1).to({scaleX:1.4526,scaleY:1.4525,y:56.15},0).wait(1).to({scaleX:1.4576,scaleY:1.4575,y:55.05},0).wait(1).to({scaleX:1.4625,scaleY:1.4624,y:53.9},0).wait(1).to({scaleX:1.4675,scaleY:1.4674,y:52.8},0).wait(1).to({scaleX:1.4725,scaleY:1.4724,x:150.6,y:51.7},0).wait(1).to({scaleX:1.4775,scaleY:1.4774,y:50.55},0).wait(1).to({scaleX:1.4824,scaleY:1.4823,y:49.45},0).wait(1).to({scaleX:1.4874,scaleY:1.4873,y:48.3},0).wait(1).to({scaleX:1.4924,scaleY:1.4923,y:47.2},0).wait(1).to({scaleX:1.4974,scaleY:1.4973,y:46.05},0).wait(1).to({scaleX:1.5023,scaleY:1.5022,y:44.95},0).wait(1).to({scaleX:1.5073,scaleY:1.5072,y:43.85},0).wait(1).to({scaleX:1.5123,scaleY:1.5122,y:42.7},0).wait(1).to({scaleX:1.5173,scaleY:1.5171,y:41.6},0).wait(1).to({scaleX:1.5222,scaleY:1.5221,y:40.5},0).wait(1).to({scaleX:1.5272,scaleY:1.5271,y:39.4},0).wait(1).to({scaleX:1.5322,scaleY:1.5321,x:150.55,y:38.25},0).wait(1).to({scaleX:1.5372,scaleY:1.537,y:37.1},0).wait(1).to({scaleX:1.5421,scaleY:1.542,y:36},0).wait(1).to({scaleX:1.5471,scaleY:1.547,y:34.85},0).wait(1).to({scaleX:1.5521,scaleY:1.552,y:33.75},0).wait(1).to({scaleX:1.557,scaleY:1.5569,y:32.65},0).wait(1).to({scaleX:1.562,scaleY:1.5619,y:31.55},0).wait(1).to({scaleX:1.567,scaleY:1.5669,y:30.4},0).wait(1).to({scaleX:1.572,scaleY:1.5718,y:29.3},0).wait(1).to({scaleX:1.5769,scaleY:1.5768,y:28.2},0).wait(1).to({scaleX:1.5819,scaleY:1.5818,y:27.05},0).wait(1).to({scaleX:1.5869,scaleY:1.5868,y:25.9},0).wait(1).to({scaleX:1.5919,scaleY:1.5917,y:24.8},0).wait(1).to({scaleX:1.5968,scaleY:1.5967,x:150.5,y:23.7},0).wait(1).to({scaleX:1.6018,scaleY:1.6017,y:22.55},0).wait(1).to({scaleX:1.6068,scaleY:1.6066,y:21.45},0).wait(1).to({scaleX:1.6118,scaleY:1.6116,y:20.35},0).wait(1).to({scaleX:1.6167,scaleY:1.6166,y:19.2},0).wait(1).to({scaleX:1.6217,scaleY:1.6216,y:18.1},0).wait(1).to({scaleX:1.6267,scaleY:1.6265,y:17},0).wait(29));

	// BG
	this.instance_18 = new lib.Symbol9();
	this.instance_18.setTransform(192.6,340.2,2.5178,1.0417,0,0,0,213.7,326.6);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(24).to({_off:false},0).wait(1).to({regX:224,regY:336,scaleX:2.5144,scaleY:1.0423,x:218.5,y:349.4},0).wait(1).to({scaleX:2.5109,scaleY:1.0429,y:348.8},0).wait(1).to({scaleX:2.5075,scaleY:1.0435,x:218.45,y:348.2},0).wait(1).to({scaleX:2.504,scaleY:1.0441,y:347.6},0).wait(1).to({scaleX:2.5006,scaleY:1.0446,y:347},0).wait(1).to({scaleX:2.4971,scaleY:1.0452,x:218.4,y:346.35},0).wait(1).to({scaleX:2.4937,scaleY:1.0458,y:345.75},0).wait(1).to({scaleX:2.4902,scaleY:1.0464,x:218.35,y:345.15},0).wait(1).to({scaleX:2.4868,scaleY:1.047,y:344.55},0).wait(1).to({scaleX:2.4833,scaleY:1.0476,x:218.3,y:343.95},0).wait(1).to({scaleX:2.4798,scaleY:1.0482,y:343.35},0).wait(1).to({scaleX:2.4764,scaleY:1.0488,x:218.25,y:342.7},0).wait(1).to({scaleX:2.4729,scaleY:1.0494,y:342.1},0).wait(1).to({scaleX:2.4695,scaleY:1.05,x:218.2,y:341.5},0).wait(1).to({scaleX:2.466,scaleY:1.0506,y:340.9},0).wait(1).to({scaleX:2.4626,scaleY:1.0511,x:218.15,y:340.3},0).wait(1).to({scaleX:2.4591,scaleY:1.0517,y:339.7},0).wait(1).to({scaleX:2.4557,scaleY:1.0523,x:218.1,y:339.05},0).wait(1).to({scaleX:2.4522,scaleY:1.0529,y:338.45},0).wait(1).to({scaleX:2.4487,scaleY:1.0535,x:218.05,y:337.85},0).wait(1).to({scaleX:2.4453,scaleY:1.0541,y:337.25},0).wait(1).to({scaleX:2.4418,scaleY:1.0547,x:218,y:336.6},0).wait(1).to({scaleX:2.4384,scaleY:1.0553,y:336},0).wait(1).to({scaleX:2.4349,scaleY:1.0559,x:217.95,y:335.35},0).wait(1).to({scaleX:2.4315,scaleY:1.0565,y:334.75},0).wait(1).to({scaleX:2.428,scaleY:1.0571,x:217.9,y:334.15},0).wait(1).to({scaleX:2.4246,scaleY:1.0576,y:333.55},0).wait(1).to({scaleX:2.4211,scaleY:1.0582,x:217.85,y:332.95},0).wait(1).to({scaleX:2.4176,scaleY:1.0588,y:332.35},0).wait(1).to({scaleX:2.4142,scaleY:1.0594,y:331.7},0).wait(1).to({scaleX:2.4107,scaleY:1.06,x:217.8,y:331.1},0).wait(1).to({scaleX:2.4073,scaleY:1.0606,y:330.5},0).wait(1).to({scaleX:2.4038,scaleY:1.0612,x:217.75,y:329.9},0).wait(1).to({scaleX:2.4004,scaleY:1.0618,x:217.7,y:329.3},0).wait(1).to({scaleX:2.3969,scaleY:1.0624,x:217.65,y:328.7},0).wait(1).to({scaleX:2.3935,scaleY:1.063,y:328.05},0).wait(1).to({scaleX:2.39,scaleY:1.0635,x:217.6,y:327.45},0).wait(1).to({scaleX:2.3865,scaleY:1.0641,y:326.85},0).wait(1).to({scaleX:2.3831,scaleY:1.0647,x:217.55,y:326.25},0).wait(1).to({scaleX:2.3796,scaleY:1.0653,y:325.65},0).wait(1).to({scaleX:2.3762,scaleY:1.0659,x:217.5,y:325.05},0).wait(1).to({scaleX:2.3727,scaleY:1.0665,y:324.4},0).wait(1).to({scaleX:2.3693,scaleY:1.0671,x:217.45,y:323.8},0).wait(1).to({scaleX:2.3658,scaleY:1.0677,y:323.2},0).wait(1).to({scaleX:2.3624,scaleY:1.0683,x:217.4,y:322.6},0).wait(1).to({scaleX:2.3589,scaleY:1.0689,y:322},0).wait(1).to({scaleX:2.3554,scaleY:1.0695,x:217.35,y:321.4},0).wait(1).to({scaleX:2.352,scaleY:1.07,y:320.75},0).wait(1).to({scaleX:2.3485,scaleY:1.0706,x:217.3,y:320.15},0).wait(1).to({scaleX:2.3451,scaleY:1.0712,y:319.55},0).wait(1).to({scaleX:2.3416,scaleY:1.0718,x:217.25,y:318.95},0).wait(1).to({scaleX:2.3382,scaleY:1.0724,y:318.35},0).wait(1).to({scaleX:2.3347,scaleY:1.073,x:217.2,y:317.75},0).wait(1).to({scaleX:2.3313,scaleY:1.0736,y:317.05},0).wait(1).to({scaleX:2.3278,scaleY:1.0742,x:217.15,y:316.45},0).wait(1).to({scaleX:2.3243,scaleY:1.0748,y:315.85},0).wait(1).to({scaleX:2.3209,scaleY:1.0754,y:315.25},0).wait(1).to({scaleX:2.3174,scaleY:1.076,x:217.1,y:314.65},0).wait(1).to({scaleX:2.314,scaleY:1.0765,y:314.05},0).wait(1).to({scaleX:2.3105,scaleY:1.0771,x:217.05,y:313.4},0).wait(1).to({scaleX:2.3071,scaleY:1.0777,y:312.8},0).wait(1).to({scaleX:2.3036,scaleY:1.0783,x:217,y:312.2},0).wait(1).to({scaleX:2.3002,scaleY:1.0789,y:311.6},0).wait(1).to({scaleX:2.2967,scaleY:1.0795,x:216.95,y:311},0).wait(1).to({scaleX:2.2932,scaleY:1.0801,y:310.4},0).wait(1).to({scaleX:2.2898,scaleY:1.0807,x:216.9,y:309.75},0).wait(1).to({scaleX:2.2863,scaleY:1.0813,y:309.15},0).wait(1).to({scaleX:2.2829,scaleY:1.0819,x:216.85,y:308.55},0).wait(1).to({scaleX:2.2794,scaleY:1.0825,x:216.8,y:307.95},0).wait(1).to({scaleX:2.276,scaleY:1.083,x:216.75,y:307.35},0).wait(1).to({scaleX:2.2725,scaleY:1.0836,y:306.75},0).wait(1).to({scaleX:2.2691,scaleY:1.0842,x:216.7,y:306.1},0).wait(1).to({scaleX:2.2656,scaleY:1.0848,y:305.5},0).wait(1).to({scaleX:2.2621,scaleY:1.0854,x:216.65,y:304.9},0).wait(1).to({scaleX:2.2587,scaleY:1.086,y:304.3},0).wait(1).to({scaleX:2.2552,scaleY:1.0866,x:216.6,y:303.7},0).wait(1).to({scaleX:2.2518,scaleY:1.0872,y:303.05},0).wait(1).to({scaleX:2.2483,scaleY:1.0878,x:216.55,y:302.45},0).wait(1).to({scaleX:2.2449,scaleY:1.0884,y:301.85},0).wait(1).to({scaleX:2.2414,scaleY:1.089,y:301.25},0).wait(1).to({scaleX:2.238,scaleY:1.0895,x:216.5,y:300.65},0).wait(1).to({scaleX:2.2345,scaleY:1.0901,y:300.05},0).wait(1).to({scaleX:2.231,scaleY:1.0907,x:216.45,y:299.4},0).wait(1).to({scaleX:2.2276,scaleY:1.0913,y:298.8},0).wait(1).to({scaleX:2.2241,scaleY:1.0919,x:216.4,y:298.2},0).wait(1).to({scaleX:2.2207,scaleY:1.0925,y:297.55},0).wait(1).to({scaleX:2.2172,scaleY:1.0931,x:216.35,y:296.95},0).wait(1).to({scaleX:2.2138,scaleY:1.0937,y:296.35},0).wait(1).to({scaleX:2.2103,scaleY:1.0943,x:216.3,y:295.7},0).wait(1).to({scaleX:2.2069,scaleY:1.0949,y:295.1},0).wait(1).to({scaleX:2.2034,scaleY:1.0955,x:216.25,y:294.5},0).wait(1).to({scaleX:2.1999,scaleY:1.096,y:293.9},0).wait(1).to({scaleX:2.1965,scaleY:1.0966,x:216.2,y:293.3},0).wait(1).to({scaleX:2.193,scaleY:1.0972,y:292.7},0).wait(1).to({scaleX:2.1896,scaleY:1.0978,x:216.15,y:292.05},0).wait(1).to({scaleX:2.1861,scaleY:1.0984,y:291.45},0).wait(1).to({scaleX:2.1827,scaleY:1.099,x:216.1,y:290.85},0).wait(1).to({scaleX:2.1792,scaleY:1.0996,y:290.25},0).wait(1).to({scaleX:2.1758,scaleY:1.1002,x:216.05,y:289.65},0).wait(1).to({scaleX:2.1723,scaleY:1.1008,y:289.05},0).wait(1).to({scaleX:2.1688,scaleY:1.1014,x:216,y:288.4},0).wait(1).to({scaleX:2.1654,scaleY:1.102,y:287.8},0).wait(1).to({scaleX:2.1619,scaleY:1.1025,x:215.95,y:287.2},0).wait(1).to({scaleX:2.1585,scaleY:1.1031,x:215.9,y:286.6},0).wait(1).to({scaleX:2.155,scaleY:1.1037,x:215.85,y:286},0).wait(1).to({scaleX:2.1516,scaleY:1.1043,y:285.4},0).wait(1).to({scaleX:2.1481,scaleY:1.1049,x:215.8,y:284.75},0).wait(1).to({scaleX:2.1447,scaleY:1.1055,y:284.15},0).wait(1).to({scaleX:2.1412,scaleY:1.1061,y:283.55},0).wait(1).to({scaleX:2.1377,scaleY:1.1067,x:215.75,y:282.95},0).wait(1).to({scaleX:2.1343,scaleY:1.1073,y:282.35},0).wait(1).to({scaleX:2.1308,scaleY:1.1079,x:215.7,y:281.75},0).wait(1).to({scaleX:2.1274,scaleY:1.1084,y:281.1},0).wait(1).to({scaleX:2.1239,scaleY:1.109,x:215.65,y:280.5},0).wait(1).to({scaleX:2.1205,scaleY:1.1096,y:279.9},0).wait(1).to({scaleX:2.117,scaleY:1.1102,x:215.6,y:279.3},0).wait(1).to({scaleX:2.1136,scaleY:1.1108,y:278.7},0).wait(1).to({scaleX:2.1101,scaleY:1.1114,x:215.55,y:278.1},0).wait(1).to({scaleX:2.1066,scaleY:1.112,y:277.45},0).wait(1).to({scaleX:2.1032,scaleY:1.1126,x:215.5,y:276.85},0).wait(1).to({scaleX:2.0997,scaleY:1.1132,y:276.25},0).wait(1).to({scaleX:2.0963,scaleY:1.1138,x:215.45,y:275.6},0).wait(1).to({scaleX:2.0928,scaleY:1.1144,y:275},0).wait(1).to({scaleX:2.0894,scaleY:1.1149,x:215.4,y:274.4},0).wait(1).to({scaleX:2.0859,scaleY:1.1155,y:273.75},0).wait(1).to({scaleX:2.0825,scaleY:1.1161,x:215.35,y:273.15},0).wait(29));

	// Layer_7
	this.instance_19 = new lib.Symbol2();
	this.instance_19.setTransform(151.5,255.5,1,1,0,0,0,138.5,101.5);
	this.instance_19.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(5).to({alpha:0.1667},0).wait(1).to({alpha:0.3333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6667},0).wait(1).to({alpha:0.8333},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.8571},0).wait(1).to({alpha:0.7143},0).wait(1).to({alpha:0.5714},0).wait(1).to({alpha:0.4286},0).wait(1).to({alpha:0.2857},0).wait(1).to({alpha:0.1429},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(161));

	// Layer_6
	this.instance_20 = new lib.Symbol1();
	this.instance_20.setTransform(151,254.9,1,1,0,0,0,138,100.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(19).to({scaleX:0.8339,scaleY:0.8342,y:255.1,alpha:0.8333},0).wait(1).to({scaleX:0.6679,scaleY:0.6683,x:150.95,y:255.35,alpha:0.6667},0).wait(1).to({scaleX:0.5018,scaleY:0.5025,y:255.6,alpha:0.5},0).wait(1).to({scaleX:0.3358,scaleY:0.3366,x:151,y:255.8,alpha:0.3333},0).wait(1).to({scaleX:0.1697,scaleY:0.1708,x:150.95,y:256.05,alpha:0.1667},0).wait(1).to({scaleX:0.0036,scaleY:0.0049,y:256.3,alpha:0},0).to({_off:true},1).wait(154));

	// Layer_4
	this.instance_21 = new lib._300x600LifestyleAnticipation21();
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(22).to({_off:false},0).to({_off:true},2).wait(155));

	// Layer_3
	this.instance_22 = new lib._300x600LifestyleAnticipation20();
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(20).to({_off:false},0).to({_off:true},2).wait(157));

	// Layer_2
	this.instance_23 = new lib._300x600LifestyleAnticipation19();

	this.timeline.addTween(cjs.Tween.get(this.instance_23).to({_off:true},20).wait(159));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-195.5,60,978,640);
// library properties:
lib.properties = {
	id: 'EC325137A56C46D1B852F251C98F2049',
	width: 300,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x600LifestyleAnticipation19.jpg?1627028147115", id:"_300x600LifestyleAnticipation19"},
		{src:"images/300x600LifestyleAnticipation2.png?1627028147115", id:"_300x600LifestyleAnticipation2"},
		{src:"images/300x600LifestyleAnticipation20.jpg?1627028147115", id:"_300x600LifestyleAnticipation20"},
		{src:"images/300x600LifestyleAnticipation21.jpg?1627028147115", id:"_300x600LifestyleAnticipation21"},
		{src:"images/Awan.png?1627028147115", id:"Awan"},
		{src:"images/BG.jpg?1627028147115", id:"BG"},
		{src:"images/Button.png?1627028147115", id:"Button"},
		{src:"images/flavor.png?1627028147115", id:"flavor"},
		{src:"images/GHW.jpg?1627028147115", id:"GHW"},
		{src:"images/kursor.png?1627028147115", id:"kursor"},
		{src:"images/Logo300x600.png?1627028147115", id:"Logo300x600"},
		{src:"images/pursue.png?1627028147115", id:"pursue"},
		{src:"images/talent.png?1627028147115", id:"talent"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EC325137A56C46D1B852F251C98F2049'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;