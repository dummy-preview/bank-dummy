var pin = document.querySelector('.pin-expand-banner');
var pinWrap = document.querySelector('.pin-expand');
var pinBannerClose = document.querySelector('.pin-expand-close');

function pinExpnadShow(){
    pin.classList.add('pin-expand--expand');
}
function pinExpnadhide(){
    pin.classList.remove('pin-expand--expand');
}
function pinScrollExpand(){
    var winScrollPin = document.body.scrollTop || document.documentElement.scrollTop;
    var pointSetPin = 550;

    if (winScrollPin > pointSetPin && winScrollPin < 3000) {
        pinExpnadShow();
    } else {
        pinExpnadhide();
    } 
}

//close
pinBannerClose.addEventListener("click", function(){
    pinWrap.style.display = "none";
    window.removeEventListener("scroll", pinScrollExpand); 
});   

//run scroll
window.addEventListener("scroll", pinScrollExpand); 
