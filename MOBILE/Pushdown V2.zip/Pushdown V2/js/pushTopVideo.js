window.addEventListener("load", function() {
  //element
  var pushTopVideo = document.querySelector(".pushTopVideo");
  var pushTopVideoItem = document.querySelector(".pushTopVideo__video__item");
  var header = document.querySelector(".theader");

  // get height
  var pushTopVideo_Height = pushTopVideo.clientHeight;
  var headerTribunnews_Height = header.clientHeight;

  //
  var btnOpen = document.querySelector("#btnOpen");
  var iconPlay = document.querySelector(".pushTopVideo__iconplay");
  var btnClose = document.querySelector(".pushTopClose");
  var bodyPost = document.getElementsByTagName("body")[0];

  //trigger
  function pushTopVideo__scroll() {
    var element = document.querySelector("#div-Inside-MediumRectangle");
    var position = element.getBoundingClientRect();

    var pushTopVideo_Height = pushTopVideo.clientHeight;

    console.log("pushTopVideo_Height :" + pushTopVideo_Height);

    // checking whether fully visible
    if (position.top <= 0 && position.bottom <= window.innerHeight) {
      ///play
      pushTopVideo.style.display = "block";
      header.style.top = pushTopVideo_Height + "px";
    } else {
      pushTopVideo.style.display = "none";
      header.style.top = 0;
      if (pushTopVideoItem != null) {
        pushTopVideoItem.pause();
        pushTopVideoItem.muted = true;
      }
    }
  }

  window.addEventListener("scroll", pushTopVideo__scroll);

  btnOpen.addEventListener("click", function() {
    clickOpen();
  });

  btnClose.addEventListener("click", function() {
    clickClose();
    window.removeEventListener("scroll", pushTopVideo__scroll);
  });

  function clickOpen() {
    bodyPost.classList.add("pushTopOpen");
    pushTopVideoItem.play();
    pushTopVideoItem.controls = false;
    pushTopVideoItem.muted = false;
    iconPlay.style.display = "none";
    btnOpen.style.display = "none";

    setTimeout(function() {
      var pushTopVideo_Height = pushTopVideo.clientHeight;
      header.style.top = pushTopVideo_Height + "px";
    }, 200);
  }
  function clickClose() {
    bodyPost.classList.remove("pushTopOpen");
    pushTopVideo.style.display = "none";
    header.style.top = "0px";
    if (pushTopVideoItem != null) {
      pushTopVideoItem.pause();
      pushTopVideoItem.muted = true;
    }
  }
});
