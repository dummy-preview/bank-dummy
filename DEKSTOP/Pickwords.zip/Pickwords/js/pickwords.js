window.addEventListener("load", function () {
  var pickwordImgSrc = "images/320x100/index.html";
  var pickwordUrl = "https://www.tribunnews.com/";
  var pickwordsColorA = "";
  var pickwordsColorB = "";
  var pickwordsIconColor = "";
  var pickwordsColorBgGradient =
    "linear-gradient(30deg, " + pickwordsColorA + " , " + pickwordsColorB + ")";
  var pickwordsColorText = "#000";
  var pickwords = document.querySelectorAll(".pickwords");
  var pickwordsHead = document.querySelector(".pickwordsHead");

  function pickwordsHover() {
    var x, i;
    x = pickwords;
    var tulip = 0;

    //span cangkang tulip
    var pickwordsHeadParent = pickwordsHead.parentElement;
    var pickwordSpan = document.createElement("span");    
    pickwordSpan.setAttribute("class", "tulip");

    //div materi tulip   
    var pickwordsTulip = document.createElement("div");
    pickwordsTulip.setAttribute("class", "pickwordsTulip");
    var ImgSrc = pickwordImgSrc;
    var pickwordsImg = document.createElement("iframe");
    pickwordsImg.setAttribute("src", ImgSrc);
    pickwordsImg.style.width = "320px";
    pickwordsImg.style.height = "100px";
    pickwordSpan.appendChild(pickwordsTulip);
    pickwordsTulip.appendChild(pickwordsImg);

    //click tulip
    pickwordsTulip.addEventListener("click", function (event) {
      window.open(pickwordUrl);
    });

    //btn close
    var pickwordsClose = document.createElement("div");
    pickwordsClose.setAttribute("class", "btnTulipClose");
    pickwordSpan.appendChild(pickwordsClose);
    var pickwordsCloseImg = document.createElement("IMG");
    pickwordsCloseImg.setAttribute("src", "images/close.png");
    pickwordsClose.appendChild(pickwordsCloseImg);
    //action close
    pickwordsClose.addEventListener("click", function(){
      console.log("close");
      pickwordSpan.classList.remove("activeTulip");
    });
        
    //print popup
    pickwordsHeadParent.appendChild(pickwordSpan);


    //loop key style
    for (i = 0; i < x.length; i++) {      
      
      //highlight pickwords
      x[i].style.cssText =
        " color:" +
        pickwordsColorText +
        " !important; background: " +
        pickwordsColorBgGradient +
        ";background-size: 180% 180%;-webkit-animation: AnimationName 1.5s ease infinite;-moz-animation: AnimationName 1.5s ease infinite;animation: AnimationName 1.5s ease infinite;";   

    //hover or tap and hide tulip
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))
    {
      // desktop     
        ["click"].forEach(function (event) {
          x[i].addEventListener(
            event,
            function () {
              pickwordSpan.classList.add("activeTulip");
            },
            false
          );
        });       
    } 
    else 
    {        
      //mobile
      x[i].addEventListener("click", function (event) {
        pickwordSpan.classList.add("activeTulip");
      });    
    }
    }
  }

  //run
  pickwordsHover();

  
});